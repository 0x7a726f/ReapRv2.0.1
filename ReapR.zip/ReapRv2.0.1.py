import os
import random
os.system("")
class style():
    RED = '\033[31m'
from time import sleep as s
print(style.RED + "               ...\n             ;::::;\n           ;::::; :;\n         ;:::::'   :;\n        ;:::::;     ;.\n       ,:::::'       ;           OOO\ \n       ::::::;       ;          OOOOO\ \n       ::::::;       ;          OOOOO\ \n       ;:::::;       ;         OOOOOOOO\n      ,;::::::;     ;'         / OOOOOOO\n    ;:::::::::`. ,,,;.        /  / DOOOOOO\n  .';:::::::::::::::::;,     /  /     DOOOO\n ,::::::;::::::;;;;::::;,   /  /        DOOO\n;`::::::`'::::::;;;::::: ,#/  /          DOOO\n:`:::::::`;::::::;;::: ;::#  /            DOOO\n::`:::::::`;:::::::: ;::::# /              DOO\n`:`:::::::`;:::::: ;::::::#/               DOO\n :::`:::::::`;; ;:::::::::##                OO\n ::::`:::::::`;::::::::;:::#                OO\n `:::::`::::::::::::;'`:;::#                O\n  `:::::`::::::::;' /  / `:#\n   ::::::`:::::;'  /  /   `#")
print("ReapR v2.0.1")
def Input():
    try:
        IpInput = str(input("IP:"))
        global SecInput
        SecInput = int(input("Seconds |1-1000|: "))
        if SecInput < 1 or SecInput > 1000 :
            print("Error")
            Input()
        else :
            BotInput = int(input("Botnet size |100-5000|: "))
            if BotInput < 100 or BotInput > 5000 :
                print("Error")
                Input()
            else:
                YesNo = input("Start? |y/n|")
                if YesNo == "y" or YesNo == "n" or YesNo == "Y" or YesNo == "N":
                    print("Initiating...")
                    s(5)
                    attack()
                else:
                    print("Error")
                    Input()
    except:
        print("Error")
        Input()

def attack():
    i = 0
    while i < int(SecInput):
        print("Botnet traffic sent successfully...")
        e = random.randint(1,3)
        r = e/10
        s(r)            
        i = i+r
Input()